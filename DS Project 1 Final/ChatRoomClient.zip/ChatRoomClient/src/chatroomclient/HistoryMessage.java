package chatroomclient;

/* Team Information

*Mohammed Fahad Kaleem(1000969369)
*Nitin Kamani(1000919137)
*Sarabjeet Singh(1001115369)
*Mohammed Mudassir Ahmed(1001108922)

*/

public class HistoryMessage {
    public String seesion;
    public String date;
    public String roomid;
    public String chatlog;
    
}